To debug when you want to run the application from command line 

java -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=8000 -jar target/16_spring_boot_devtools-0.0.1-SNAPSHOT.jar

Run -> Debug Configuration -> Remote Java Application
