package com.st.spring.boot.util;

public class Constants {
	
	public static final String USER_NAME = "USER_NAME";

}
