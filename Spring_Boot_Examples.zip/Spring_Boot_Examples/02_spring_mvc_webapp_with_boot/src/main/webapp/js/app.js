/**
 * 
 */
function hello() {
	console.log("Hello World JS")
}