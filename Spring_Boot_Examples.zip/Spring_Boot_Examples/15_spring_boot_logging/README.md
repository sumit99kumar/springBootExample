We can use actuator APIs to change the log level

 http://localhost:8080/loggers/ROOT
 http://localhost:8080/loggers/com.mi
 
Request Body
	{
  		"configuredLevel": "INFO"
	}